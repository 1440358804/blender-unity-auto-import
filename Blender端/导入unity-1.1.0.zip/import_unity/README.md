# 导入unity

Blender 4.0+ 插件。它将选中的网格物体导出到 Unity 项目的 `Assets/`，并在 FBX 同目录写入 Unity 可读的导入配置；同时支持把常用的 FBX、材质和 Prefab 位置保存成多个命名按键。Unity Editor 需要打开该项目，才能自动绑定已存在材质并生成 Prefab。

当前版本：**1.1.0**

## 安装

1. 在 Blender 打开 Edit > Preferences > Add-ons，点击右上角菜单并选择 Install from Disk。
2. 选择 `导入unity-1.1.0.zip` 并点击 Install Add-on。
3. 在 Add-ons 列表搜索并启用“导入unity”。
4. 在 3D View 按 `N`，打开“导入unity”侧栏。

## 使用

1. 选择 Unity 项目根目录（应包含 `ProjectSettings/ProjectVersion.txt`）。
2. 点击“根据 Unity 根目录生成默认路径”，插件会生成以下默认位置：`Assets/Game/Art/Environment/TokyoRooftops`、`Assets/Game/WorldMap/Props/Materials` 和 `Assets/Game/WorldMap/Props/TokyoRooftops`。
3. 点击“创建按键”，会新增一个可折叠的下拉面板。面板内包含：
   - FBX 导入位置
   - 材质搜索位置
   - Prefab 保存位置
   - 按键名称
4. 填写或修改这些选项，然后点击“保存按键”。保存成功后：
   - 下拉面板收起，收起状态仍显示按键名称；
   - 面板外的“已保存按键”区域出现一个同名按键。
5. 点击“已保存按键”中的按键，会把它保存的三个位置设为当前导出位置；当前按键带勾选标记。之后选中网格物体，点击“导出并导入 Unity”即可。
6. 需要多套位置时，重复“创建按键”。每个下拉面板都可以单独展开、修改和再次保存；垃圾桶图标可删除按键。
7. “模型名称”和“导入名称”仍在外层。选中要导出的物体后点击“导入名称”，可把最后选中的网格物体名称填入“模型名称”。多选时使用最后选中的物体。

按键配置保存在当前 `.blend` 文件中。保存按键或点击已保存按键时，会把该按键的三个位置同步为当前导出位置；新建按键会继承当前按键的位置。若已存在当前按键，点击“根据 Unity 根目录生成默认路径”也会回填该按键。

材质只在指定目录按精确名称匹配。唯一匹配会绑定；找不到时保留 FBX 导入材质且不创建 `.mat`；重名候选会报错并停止处理。Prefab 目录中已存在但不属于本插件的同名 Prefab 不会被覆盖。

## FBX 参数

- 仅导出选中物体中的 Mesh。
- Scale 1.00，Apply Scalings = FBX Unit Scale。
- Forward = -Z Forward，Up = Y Up。
- Apply Unit Scale、Use Space Transform、Apply Transform 开启。
- Custom Properties 关闭。

插件会检查当前 FBX exporter 是否提供这些必要属性；缺少时停止导出。材质贴图打包、动画和骨架不是本插件的处理目标。

## 版本记录

- **1.1.0**：新增“创建按键”、可折叠按键面板、自定义按键名称、“保存按键”及面板外同名按键。
- **1.0.0**：初始版本。

Blender 端安装包文件名带版本号；每次发布新安装包时都会递增版本号。

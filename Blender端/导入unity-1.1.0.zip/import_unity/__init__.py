bl_info = {
    "name": "导入unity",
    "author": "OpenAI",
    "version": (1, 1, 0),
    "blender": (4, 0, 0),
    "location": "View3D > Sidebar > 导入unity",
    "description": "Export selected mesh objects to a Unity project with reusable named export buttons",
    "category": "Import-Export",
}

import json
import os
import tempfile
import bpy
from bpy.props import BoolProperty, CollectionProperty, IntProperty, StringProperty


DEFAULT_MODEL_RELATIVE_PATH = os.path.join("Assets", "Game", "Art", "Environment", "TokyoRooftops")
DEFAULT_MATERIAL_RELATIVE_PATH = os.path.join("Assets", "Game", "WorldMap", "Props", "Materials")
DEFAULT_PREFAB_RELATIVE_PATH = os.path.join("Assets", "Game", "WorldMap", "Props", "TokyoRooftops")
UNNAMED_KEY = "未命名按键"


def _normal(path):
    return os.path.normcase(os.path.realpath(bpy.path.abspath(path)))


def _absolute(path):
    # Keep the filesystem's original casing for Unity asset paths in the sidecar.
    return os.path.realpath(bpy.path.abspath(path))


def _inside(path, parent):
    try:
        return os.path.commonpath((_normal(path), _normal(parent))) == _normal(parent)
    except ValueError:
        return False


def _last_selected_mesh(context):
    active = context.view_layer.objects.active
    if active is not None and active.select_get() and active.type == 'MESH':
        return active
    meshes = [obj for obj in context.selected_objects if obj.type == 'MESH']
    return meshes[-1] if meshes else None


def _default_paths(scene):
    project = _absolute(scene.unityimport_project_root)
    if not os.path.isdir(project) or not os.path.isfile(os.path.join(project, "ProjectSettings", "ProjectVersion.txt")):
        return None
    return (
        os.path.join(project, DEFAULT_MODEL_RELATIVE_PATH),
        os.path.join(project, DEFAULT_MATERIAL_RELATIVE_PATH),
        os.path.join(project, DEFAULT_PREFAB_RELATIVE_PATH),
    )


def _key_display_name(key):
    return key.key_name.strip() or UNNAMED_KEY


def _unique_key_name(keys):
    existing = {key.key_name.strip() for key in keys}
    if "按键" not in existing:
        return "按键"
    index = 1
    while "按键 " + str(index) in existing:
        index += 1
    return "按键 " + str(index)


def _active_key(scene):
    keys = scene.unityimport_keys
    index = scene.unityimport_active_key
    if 0 <= index < len(keys):
        return keys[index]
    return None


def _export_directories(scene):
    key = _active_key(scene)
    if key is not None:
        return key.fbx_directory, key.material_directory, key.prefab_directory
    return (
        scene.unityimport_model_directory,
        scene.unityimport_material_directory,
        scene.unityimport_prefab_directory,
    )


def _apply_key_to_export(scene, key):
    # Keep the legacy scene paths in sync with the active key.
    scene.unityimport_model_directory = key.fbx_directory
    scene.unityimport_material_directory = key.material_directory
    scene.unityimport_prefab_directory = key.prefab_directory


class UNITYIMPORT_Key(bpy.types.PropertyGroup):
    key_name: StringProperty(name="按键名称", default="按键")
    fbx_directory: StringProperty(
        name="FBX 导入位置", subtype='DIR_PATH', default=DEFAULT_MODEL_RELATIVE_PATH)
    material_directory: StringProperty(
        name="材质搜索位置", subtype='DIR_PATH', default=DEFAULT_MATERIAL_RELATIVE_PATH)
    prefab_directory: StringProperty(
        name="Prefab 保存位置", subtype='DIR_PATH', default=DEFAULT_PREFAB_RELATIVE_PATH)
    expanded: BoolProperty(name="展开", default=True)
    saved: BoolProperty(name="已保存", default=False)


class UNITYIMPORT_OT_set_defaults(bpy.types.Operator):
    bl_idname = "unityimport.set_defaults"
    bl_label = "根据 Unity 根目录生成默认路径"
    bl_description = "按 Unity 项目根目录生成 FBX、材质和 Prefab 默认位置；有当前按键时同时回填该按键"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        paths = _default_paths(scene)
        if paths is None:
            self.report({'ERROR'}, "请选择有效的 Unity 项目根目录")
            return {'CANCELLED'}

        scene.unityimport_model_directory = paths[0]
        scene.unityimport_material_directory = paths[1]
        scene.unityimport_prefab_directory = paths[2]
        key = _active_key(scene)
        if key is not None:
            key.fbx_directory = paths[0]
            key.material_directory = paths[1]
            key.prefab_directory = paths[2]
        self.report({'INFO'}, "已根据 Unity 根目录生成默认路径")
        return {'FINISHED'}


class UNITYIMPORT_OT_import_name(bpy.types.Operator):
    bl_idname = "unityimport.import_name"
    bl_label = "导入名称"
    bl_description = "将最后选中的物体名称填入模型名称；多选时使用最后选中的物体"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        selected = _last_selected_mesh(context)
        if selected is None:
            self.report({'ERROR'}, "请至少选择一个网格物体")
            return {'CANCELLED'}
        context.scene.unityimport_model_name = bpy.path.clean_name(selected.name)
        self.report({'INFO'}, "已导入模型名称: " + selected.name)
        return {'FINISHED'}


class UNITYIMPORT_OT_create_key(bpy.types.Operator):
    bl_idname = "unityimport.create_key"
    bl_label = "创建按键"
    bl_description = "新建一个可配置的下拉面板，用于保存一组导出位置"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        keys = scene.unityimport_keys
        name = _unique_key_name(keys)
        source = _active_key(scene)
        key = keys.add()
        key.key_name = name
        if source is not None:
            key.fbx_directory = source.fbx_directory
            key.material_directory = source.material_directory
            key.prefab_directory = source.prefab_directory
        else:
            key.fbx_directory = scene.unityimport_model_directory
            key.material_directory = scene.unityimport_material_directory
            key.prefab_directory = scene.unityimport_prefab_directory
        key.expanded = True
        key.saved = False
        scene.unityimport_active_key = len(keys) - 1
        self.report({'INFO'}, "已创建按键: " + name)
        return {'FINISHED'}


class UNITYIMPORT_OT_toggle_key(bpy.types.Operator):
    bl_idname = "unityimport.toggle_key"
    bl_label = "展开或收起按键"
    bl_description = "展开或收起按键下拉面板，并把该按键设为当前按键"
    key_index: IntProperty(default=-1, options={'HIDDEN'})

    def execute(self, context):
        scene = context.scene
        keys = scene.unityimport_keys
        if not 0 <= self.key_index < len(keys):
            self.report({'ERROR'}, "按键不存在")
            return {'CANCELLED'}
        key = keys[self.key_index]
        key.expanded = not key.expanded
        scene.unityimport_active_key = self.key_index
        return {'FINISHED'}


class UNITYIMPORT_OT_save_key(bpy.types.Operator):
    bl_idname = "unityimport.save_key"
    bl_label = "保存按键"
    bl_description = "校验并保存按键；保存后在下拉面板外生成同名按键"
    bl_options = {'REGISTER', 'UNDO'}
    key_index: IntProperty(default=-1, options={'HIDDEN'})

    def execute(self, context):
        scene = context.scene
        keys = scene.unityimport_keys
        if not 0 <= self.key_index < len(keys):
            self.report({'ERROR'}, "按键不存在")
            return {'CANCELLED'}
        key = keys[self.key_index]

        name = key.key_name.strip()
        if not name:
            self.report({'ERROR'}, "按键名称不能为空")
            return {'CANCELLED'}
        for index, other in enumerate(keys):
            if index != self.key_index and other.saved and other.key_name.strip() == name:
                self.report({'ERROR'}, "已存在同名按键: " + name)
                return {'CANCELLED'}
        for value, label in (
            (key.fbx_directory, "FBX 导入位置"),
            (key.material_directory, "材质搜索位置"),
            (key.prefab_directory, "Prefab 保存位置"),
        ):
            if not value.strip():
                self.report({'ERROR'}, label + "不能为空")
                return {'CANCELLED'}

        key.key_name = name
        key.saved = True
        key.expanded = False
        _apply_key_to_export(scene, key)
        scene.unityimport_active_key = self.key_index
        self.report({'INFO'}, "已保存按键: " + name)
        return {'FINISHED'}


class UNITYIMPORT_OT_apply_key(bpy.types.Operator):
    bl_idname = "unityimport.apply_key"
    bl_label = "使用此按键"
    bl_description = "把该按键保存的三个导出位置设为当前导出位置"
    bl_options = {'REGISTER', 'UNDO'}
    key_index: IntProperty(default=-1, options={'HIDDEN'})

    def execute(self, context):
        scene = context.scene
        keys = scene.unityimport_keys
        if not 0 <= self.key_index < len(keys):
            self.report({'ERROR'}, "按键不存在")
            return {'CANCELLED'}
        key = keys[self.key_index]
        if not key.saved:
            self.report({'ERROR'}, "该按键尚未保存")
            return {'CANCELLED'}
        _apply_key_to_export(scene, key)
        scene.unityimport_active_key = self.key_index
        self.report({'INFO'}, "已使用按键: " + _key_display_name(key))
        return {'FINISHED'}


class UNITYIMPORT_OT_delete_key(bpy.types.Operator):
    bl_idname = "unityimport.delete_key"
    bl_label = "删除按键"
    bl_description = "删除该按键及其下拉面板"
    bl_options = {'REGISTER', 'UNDO'}
    key_index: IntProperty(default=-1, options={'HIDDEN'})

    def execute(self, context):
        scene = context.scene
        keys = scene.unityimport_keys
        if not 0 <= self.key_index < len(keys):
            self.report({'ERROR'}, "按键不存在")
            return {'CANCELLED'}
        name = _key_display_name(keys[self.key_index])
        keys.remove(self.key_index)
        active = scene.unityimport_active_key
        if active == self.key_index:
            if not keys:
                scene.unityimport_active_key = -1
            elif self.key_index < len(keys):
                scene.unityimport_active_key = self.key_index
            else:
                scene.unityimport_active_key = len(keys) - 1
        elif active > self.key_index:
            scene.unityimport_active_key = active - 1
        self.report({'INFO'}, "已删除按键: " + name)
        return {'FINISHED'}


class UNITYIMPORT_OT_export(bpy.types.Operator):
    bl_idname = "unityimport.export_selected"
    bl_label = "导出并导入 Unity"
    bl_description = "导出选中的网格，并通知打开的 Unity 项目自动绑定材质及生成 Prefab"
    bl_options = {'REGISTER'}

    def execute(self, context):
        scene = context.scene
        project = _normal(scene.unityimport_project_root)
        model_path, material_path, prefab_path = _export_directories(scene)
        model_dir = _normal(model_path)
        material_dir = _normal(material_path)
        prefab_dir = _normal(prefab_path)
        if not os.path.isdir(project) or not os.path.isfile(os.path.join(project, "ProjectSettings", "ProjectVersion.txt")):
            self.report({'ERROR'}, "请选择有效的 Unity 项目根目录")
            return {'CANCELLED'}

        assets = os.path.join(project, "Assets")
        if not all(_inside(path, assets) for path in (model_dir, material_dir, prefab_dir)):
            self.report({'ERROR'}, "FBX、材质搜索和 Prefab 目录都必须位于 Unity 项目的 Assets 内")
            return {'CANCELLED'}
        if not os.path.isdir(material_dir):
            self.report({'ERROR'}, "材质搜索位置必须是 Unity Assets 内已存在的文件夹")
            return {'CANCELLED'}
        meshes = [obj for obj in context.selected_objects if obj.type == 'MESH']
        if not meshes:
            self.report({'ERROR'}, "请至少选择一个网格物体")
            return {'CANCELLED'}
        name = bpy.path.clean_name(scene.unityimport_model_name.strip())
        if not name:
            self.report({'ERROR'}, "模型文件名不能为空")
            return {'CANCELLED'}

        os.makedirs(model_dir, exist_ok=True)
        output_project = _absolute(scene.unityimport_project_root)
        output_model_dir = os.path.realpath(bpy.path.abspath(model_path))
        output_material_dir = os.path.realpath(bpy.path.abspath(material_path))
        output_prefab_dir = os.path.realpath(bpy.path.abspath(prefab_path))
        relative_model = os.path.relpath(os.path.join(output_model_dir, name + ".fbx"), output_project).replace(os.sep, "/")
        relative_material = os.path.relpath(output_material_dir, output_project).replace(os.sep, "/")
        relative_prefab = os.path.relpath(output_prefab_dir, output_project).replace(os.sep, "/")
        settings = {
            "schemaVersion": 1,
            "modelAssetPath": relative_model,
            "materialSearchDirectory": relative_material,
            "prefabDirectory": relative_prefab,
            "prefabName": name,
        }

        properties = bpy.ops.export_scene.fbx.get_rna_type().properties
        required = {
            "use_selection", "object_types", "global_scale", "apply_scale_options",
            "axis_forward", "axis_up", "apply_unit_scale", "use_space_transform",
            "bake_space_transform", "use_custom_props",
        }
        missing = sorted(required.difference(properties.keys()))
        if missing:
            self.report({'ERROR'}, "当前 Blender FBX 导出器缺少所需设置: " + ", ".join(missing))
            return {'CANCELLED'}

        result = bpy.ops.export_scene.fbx(
            filepath=os.path.join(model_dir, name + ".fbx"),
            use_selection=True,
            object_types={'MESH'},
            global_scale=1.0,
            apply_scale_options='FBX_SCALE_UNITS',
            axis_forward='-Z',
            axis_up='Y',
            apply_unit_scale=True,
            use_space_transform=True,
            bake_space_transform=True,
            use_custom_props=False,
            bake_anim=False,
            path_mode='AUTO',
        )
        if 'FINISHED' not in result:
            self.report({'ERROR'}, "Blender FBX 导出未完成")
            return {'CANCELLED'}

        settings_path = os.path.join(model_dir, name + ".fbx.acepro-import.json")
        fd, temporary_path = tempfile.mkstemp(prefix=name + ".", suffix=".tmp", dir=model_dir)
        try:
            with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as stream:
                json.dump(settings, stream, ensure_ascii=False, indent=2)
                stream.write("\n")
            os.replace(temporary_path, settings_path)
        finally:
            if os.path.exists(temporary_path):
                os.remove(temporary_path)
        self.report({'INFO'}, "FBX 和 Unity 导入设置已写入 Assets；Unity Editor 将自动处理材质和 Prefab")
        return {'FINISHED'}


class UNITYIMPORT_PT_panel(bpy.types.Panel):
    bl_label = "导入unity"
    bl_idname = "UNITYIMPORT_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "导入unity"

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        keys = scene.unityimport_keys

        layout.prop(scene, "unityimport_project_root", text="Unity 项目")
        layout.operator(UNITYIMPORT_OT_set_defaults.bl_idname, icon='FILE_REFRESH')
        layout.operator(UNITYIMPORT_OT_create_key.bl_idname, icon='ADD')

        for index, key in enumerate(keys):
            box = layout.box()
            header = box.row()
            toggle = header.operator(
                UNITYIMPORT_OT_toggle_key.bl_idname,
                text=_key_display_name(key),
                icon='TRIA_DOWN' if key.expanded else 'TRIA_RIGHT',
                emboss=False,
            )
            toggle.key_index = index
            if not key.expanded:
                continue

            column = box.column(align=True)
            column.prop(key, "fbx_directory", text="FBX 导入位置")
            column.prop(key, "material_directory", text="材质搜索位置")
            column.prop(key, "prefab_directory", text="Prefab 保存位置")
            column.prop(key, "key_name", text="按键名称")
            buttons = box.row(align=True)
            save = buttons.operator(UNITYIMPORT_OT_save_key.bl_idname, text="保存按键", icon='FILE_TICK')
            save.key_index = index
            remove = buttons.operator(UNITYIMPORT_OT_delete_key.bl_idname, text="", icon='TRASH')
            remove.key_index = index

        saved_keys = [(index, key) for index, key in enumerate(keys) if key.saved]
        if saved_keys:
            layout.separator()
            layout.label(text="已保存按键")
            for index, key in saved_keys:
                active = index == scene.unityimport_active_key
                if active:
                    use = layout.operator(
                        UNITYIMPORT_OT_apply_key.bl_idname,
                        text=_key_display_name(key),
                        icon='CHECKMARK',
                    )
                else:
                    use = layout.operator(
                        UNITYIMPORT_OT_apply_key.bl_idname,
                        text=_key_display_name(key),
                    )
                use.key_index = index

        layout.separator()
        layout.prop(scene, "unityimport_model_name", text="模型名称")
        layout.operator(UNITYIMPORT_OT_import_name.bl_idname, icon='SORTALPHA')
        layout.operator(UNITYIMPORT_OT_export.bl_idname, icon='EXPORT')


CLASSES = (
    UNITYIMPORT_Key,
    UNITYIMPORT_OT_set_defaults,
    UNITYIMPORT_OT_import_name,
    UNITYIMPORT_OT_create_key,
    UNITYIMPORT_OT_toggle_key,
    UNITYIMPORT_OT_save_key,
    UNITYIMPORT_OT_apply_key,
    UNITYIMPORT_OT_delete_key,
    UNITYIMPORT_OT_export,
    UNITYIMPORT_PT_panel,
)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.unityimport_project_root = StringProperty(name="Unity 项目根目录", subtype='DIR_PATH')
    bpy.types.Scene.unityimport_model_directory = StringProperty(
        name="FBX 导入位置", subtype='DIR_PATH', default=DEFAULT_MODEL_RELATIVE_PATH)
    bpy.types.Scene.unityimport_material_directory = StringProperty(
        name="材质搜索位置", subtype='DIR_PATH', default=DEFAULT_MATERIAL_RELATIVE_PATH)
    bpy.types.Scene.unityimport_prefab_directory = StringProperty(
        name="Prefab 保存位置", subtype='DIR_PATH', default=DEFAULT_PREFAB_RELATIVE_PATH)
    bpy.types.Scene.unityimport_model_name = StringProperty(name="模型名称", default="Model")
    bpy.types.Scene.unityimport_keys = CollectionProperty(type=UNITYIMPORT_Key)
    bpy.types.Scene.unityimport_active_key = IntProperty(name="当前按键", default=-1)


def unregister():
    for name in (
        "unityimport_project_root", "unityimport_model_directory",
        "unityimport_material_directory", "unityimport_prefab_directory", "unityimport_model_name",
        "unityimport_keys", "unityimport_active_key",
    ):
        if hasattr(bpy.types.Scene, name):
            delattr(bpy.types.Scene, name)
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
